#pragma once
#include "PathfinderInterface.h"
#include <sstream>
#include <fstream>
#include <string>
#include <stack>
#include <vector>
#include <iostream>
 using namespace std;


class Pathfinder : public PathfinderInterface
{
public:
  // default constr
	Pathfinder();
	~Pathfinder();

	// working function
	void createRandomMaze();
	bool importMaze(string Openfile);
	string toString() const;
	bool findPath(int maze[5][5][5], int x, int y, int z);
	vector<string> solveMaze();

private:
 // data type we need 
	string Openfile;
	vector<string> Path;
	int maze[5][5][5];
};














