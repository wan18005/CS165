#include "Pathfinder.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <stack>
#include <cstdlib>
using namespace std;


/*********************************************
* Pathfinder :: Pathfinder()
* Default int 5*5*5 maze  
*********************************************/
Pathfinder::Pathfinder()
{

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			for (int k = 0; k < 5; k++)
			{
				maze[i][j][k] = 1;
			}
		}
	}
}

Pathfinder::~Pathfinder() {}
 /*
File 1 - Import Maze (25 points)
For this part, you will need to implement your importMaze() and toString() functions. The importMaze function is described in the PathfinderInterface.h file, but here are some things to note:
You will be given a filename for each maze (you must keep the Mazes folder in the working directory of your project). Valid files will contain representations of mazes, with each cell represented by a 0 or a 1.
You must check to make sure that the given file contains valid maze information. Each maze should consist of exactly 125 1's or 0's. Mazes may be solvable or unsolvable.

File 2 - Invalid Import (10 points)
This test will check your importMaze() function to make sure that it properly rejects invalid mazes and filenames. A maze is invalid if it consists of anything other than exactly 125 cells, each represented by either a 0 or a 1.
Your current maze should not change during an invalid import.
Your maze should consist of all 1's if no maze has yet been imported.

File 3 - Solvable Mazes (35 points)
This will test your algorithm against several solvable mazes. Each given maze should be properly imported and solved as described in the PathfinderInterface.h file.
A valid path is one which starts at the entrance (0, 0, 0) and ends at the exit (4, 4, 4) and does not contain any cycles. When moving between cells, the divers can only move up, down, left, right, forward, and backwards one cell at a time. No diagonals are allowed.

File 4 - Unsolvable Mazes (20 points)
This will test your algorithm against several unsolvable mazes.

File 5 - Generate Random Mazes (10 points)
This will test your createRandomMaze() function and your solveMaze() function.
You will be required to generate several random mazes. Because the mazes will be randomly generated, there is no key_file5 to compare against. Rather, you should make sure that each generated maze is a valid maze. Mazes will be tested by calling solveMaze() on the generated mazes. You must return either a valid path or no path for each maze, and there should be several solvable mazes and several unsolvable mazes in the output. If you have either no solvable mazes or unsolvable mazes, run the program again until several of each are generated.
The TA will have to check to make sure your Random Mazes are correct during the verification phase of the lab grading and it will not be checked by the autograder.
 */

/*********************************************
* Pathfinder :: import
* It will import the maze  
*********************************************/
bool Pathfinder::importMaze(string Openfile)
{
	ifstream temp1;
	ifstream temp2;
	int number_count = 0;
	int check = 0;
	int count = 0;
	int input = 0;

	temp2.open(Openfile.c_str());
	if (temp2.is_open())
	{
		while (temp2 >> input)
		{
			count++; // count the maze
		}
		if (count != 125)
		{
			return false;
		}
	}
	
	temp1.open(Openfile.c_str()); // open file
	if (temp1.is_open())
	// go through the the maze
	{
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				for (int k = 0; k < 5; k++)
				{
					if (temp1.fail())
					{
						temp1.clear();
						temp1.ignore();
						return false;
					}
					else
					{
						// store the maze
						temp1 >> maze[i][j][k];
					}

				}
			}
		}
		// put it in check as well
		temp1 >> check;
		if (!temp1.fail())
		{
			temp1.clear();
			temp1.ignore();
			return false;
		}
	}
	temp1.close();

// those conditional also return false
	if (maze[0][0][0] == 0 || maze[4][4][4] == 0)
	{
		return false;
	}

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			for (int k = 0; k < 5; k++)
			{
				if (maze[i][j][k] == 0 || maze[i][j][k] == 1)
				{ 
					// count the 0 and 1
					number_count++;
				}
				else if (!isdigit(maze[i][j][k]))
				{
					return false;
				}
				else
				{
					return false;
				}
			}
		}
	}
	if (number_count != 125)
	{
		return false;
	}
	return true;
}

/*********************************************
* Pathfinder :: toString
* Convert it to a string  
*********************************************/
string Pathfinder::toString() const
{
	stringstream temp; // temp s string
	string result;  // store the result(final product)
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			for (int k = 0; k < 5; k++)
			{
				if (k == 4)
				{ 
					// if it meet the conditional store the maze
					temp << maze[i][j][k];
				}
				else if (k != 4)
				{ 
					// if not space
					temp << maze[i][j][k] << " ";
				}
			}
			temp << endl;
		}
		if (i != 4)
		{
			temp << endl;
		}
	}
	result = temp.str(); // Get C string equivalent
	return result;
}

/*********************************************
* Pathfinder :: Create Random 
* Generate random maze  
*********************************************/
void Pathfinder::createRandomMaze()
{
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			for (int k = 0; k < 5; k++)
			{
				// do a ramdom on the maze
				maze[i][j][k] = rand() % 2;
			}
		}
	}
 // vaild maze
	maze[0][0][0] = 1;
	maze[4][4][4] = 1;
}

/*********************************************
* Pathfinder :: Path finder
* Path finder for the maze it will return a true if it can find a way  
*********************************************/
bool Pathfinder::findPath(int maze[5][5][5], int x, int y, int z)
{
	stringstream ss;
	string point;
	ss << z << ", " << y << ", " << x;
	point = ss.str();
	point = "(" + point + ")";
	Path.push_back(point);
	if (x < 0 || y < 0 || z < 0 || x > 4 || y > 4 || z > 4 || maze[x][y][z] == 0 || maze[x][y][z] == 3 || maze[x][y][z] == 2)
	{
		Path.pop_back();
		return false;
	}
	else if (x == 4 && y == 4 && z == 4)
	{
		return true;
	}
	else if (maze[x][y][z] == 1)
	{
		maze[x][y][z] = 2;
		if (findPath(maze, x - 1, y, z) || findPath(maze, x + 1, y, z) || findPath(maze, x, y - 1, z) || findPath(maze, x, y + 1, z) || findPath(maze, x, y, z - 1) || findPath(maze, x, y, z + 1))
		{
			maze[x][y][z] = 1;
			return true;
		}
		else
		{
			maze[x][y][z] = 3;
			Path.pop_back();
			return false;
		}
	}
}

/*********************************************
* Pathfinder :: Solve the maze
* Path finder for the maze it will return a true if it can find a way  
*********************************************/
vector<string> Pathfinder::solveMaze()
{
	Path.clear(); // clear the data in Path
	findPath(maze, 0, 0, 0); // call maze finder function above

	for (int z = 0; z < 5; z++)
	{
		for (int y = 0; y < 5; y++)
		{
			for (int x = 0; x < 5; x++)
			{ 
				if (maze[x][y][z] == 2 || maze[x][y][z] == 3)
				{
					maze[x][y][z] = 1;
				}
			}
		}
	}
	return Path;

	// give the answer for the path
}

