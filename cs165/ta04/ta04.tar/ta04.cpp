/***************************************************************
 * File: ta04.cpp
 * Author: (your name here)
 * Purpose: Contains the main function to test the Rational class.
 ***************************************************************/

#include <iostream>
#include <string>
using namespace std;

#include "rational.h"

int main()
{
   // Declare your Rational object here
   Rational rational;


   // Call your prompt function here
   rational.prompt();
   rational.display();
   rational.displayDecimal();

   // Call your display functions here


   return 0;
}
