/*******************************************
 * File: check06a.cpp
 * 
 * You should not need to change this file.
 *******************************************/

#include <iostream>
using namespace std;

#include "robot.h"

int main()
{
   Robot r;

   cout << "Robot details: ";
   r.display();

   cout << endl;

   return 0;
}
